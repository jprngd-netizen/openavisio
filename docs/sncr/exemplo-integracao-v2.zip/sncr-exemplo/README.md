
```markdown
# Frontend - Autenticação com Gov.br por meio da API SNCR.

## Visão Geral

Frontend Angular que se integra ao backend API SNCR e realiza autenticação via GovBr, suportando **qualquer domínio** (cross-domain).

## Arquitetura

O frontend pode estar em qualquer domínio .br e se comunica com o backend via CORS ou proxy.

## Configuração por Ambiente

### Desenvolvimento (frontend local + backend remoto)

**`environment.ts`:**
```typescript
export const environment = {
  production: false,
  apiUrl: 'https://sncr-api.apps.anvisa.gov.br'  // URL completa do backend.
};
```

Proxy (opcional, para evitar CORS)

proxy.conf.js

```typescript

const PROXY_CONFIG = {
  "/api": {
    target: "https://sncr-api.apps.anvisa.gov.br",
    secure: false,
    changeOrigin: true,
    logLevel: "debug"
  }
};
module.exports = PROXY_CONFIG;
```

environment.ts (com proxy):

```typescript
export const environment = {
  production: false,
  apiUrl: ''  // Vazio = usa proxy
};
```

Serviço de Autenticação (AuthService)

```typescript
@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly TOKEN_KEY = 'auth_token';

  // Retorna URL de login
  getLoginUrl(): string {
    const clientUrl = window.location.origin + window.location.pathname;
    return `${environment.apiUrl}/api/v1/auth/login?client_url=${encodeURIComponent(clientUrl)}`;
  }

  // Busca token após callback
  async buscarToken(sessionId: string): Promise<string | null> {
    const response = await fetch(
      `${environment.apiUrl}/api/v1/auth/token?session_id=${sessionId}`,
      { method: 'GET', headers: { 'Content-Type': 'application/json' } }
    );
    
    if (!response.ok) return null;
    const data = await response.json();
    return data.access_token;
  }

  // Processa callback (quando volta com session_id na URL)
  async processarCallback(): Promise<boolean> {
    const sessionId = new URLSearchParams(window.location.search).get('session_id');
    
    if (sessionId) {
      const token = await this.buscarToken(sessionId);
      if (token) {
        this.setToken(token);
        window.history.replaceState({}, document.title, window.location.pathname);
        return true;
      }
    }
    return false;
  }

  // Getters/Setters
  setToken(token: string): void {
    localStorage.setItem(this.TOKEN_KEY, token);
  }

  getToken(): string | null {
    return localStorage.getItem(this.TOKEN_KEY);
  }

  isAuthenticated(): boolean {
    const token = this.getToken();
    if (!token) return false;
    
    // Verifica expiração do JWT
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.exp * 1000 > Date.now();
    } catch {
      return false;
    }
  }

  limparSessao(): void {
    localStorage.removeItem(this.TOKEN_KEY);
  }
}
```

Interceptor HTTP (Bearer Token)

```typescript
import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { AuthService } from '../services/auth.service';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const authService = inject(AuthService);
  const token = authService.getToken();
  
  if (token) {
    const cloned = req.clone({
      headers: req.headers.set('Authorization', `Bearer ${token}`)
    });
    return next(cloned);
  }
  
  return next(req);
};
```

Registro no app.config.ts:

```typescript
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { authInterceptor } from './interceptors/auth.interceptor';

export const appConfig: ApplicationConfig = {
  providers: [
    provideHttpClient(withInterceptors([authInterceptor]))
  ]
};
```

Componente Principal (AppComponent)

```typescript
@Component({...})
export class AppComponent implements OnInit {
  private authService = inject(AuthService);
  autenticado = false;

  async ngOnInit() {
    // Processa callback se houver session_id na URL
    await this.authService.processarCallback();
    this.autenticado = this.authService.isAuthenticated();
  }

  async fazerRequisicaoProtegida() {
    const token = this.authService.getToken();
    
    if (!token) {
      window.location.href = this.authService.getLoginUrl();
      return;
    }
    
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });
    
    this.http.post('/api/protegida', data, { headers }).subscribe({
      next: (response) => { /* sucesso */ },
      error: async (err) => {
        if (err.status === 401) {
          this.authService.limparSessao();
          window.location.href = this.authService.getLoginUrl();
        }
      }
    });
  }

  fazerLogout() {
    this.authService.limparSessao();
    this.autenticado = false;
    // Opcional: redirecionar para página inicial
  }
}
```

Fluxo Completo

```text
1. Usuário clica em "Login"
   → AppComponent chama authService.getLoginUrl()
   → Redireciona para backend

2. Backend processa e redireciona para Gov.br

3. Usuário faz login no Gov.br

4. Gov.br redireciona para callback do backend

5. Backend redireciona para frontend com ?session_id=xxx

6. Frontend (AppComponent.ngOnInit) chama processarCallback()
   → Busca session_id na URL
   → GET /api/v1/auth/token?session_id=xxx
   → Guarda access_token no localStorage
   → Limpa URL

7. Usuário autenticado pode fazer requisições
   → Interceptor adiciona token no header Authorization: Bearer xxx
```

---

## Execução do Projeto Guia Localmente

Para rodar este front-end Angular de referência em sua máquina de desenvolvimento:

1. **Configurar o Ambiente (`src/environments/environment.ts`):**
   Certifique-se de apontar o endereço da API para o seu ambiente local ou de staging:
   ```typescript
   export const environment = {
     production: false,
     apiUrl: 'https://sncr-api.dev.apps.anvisa.gov.br' // Endereço da API Java em Dev.
   };
   ```

2. **Instalar Dependências e Subir o Servidor:**
   ```bash
   npm install
   ng serve
   ```
   Acesse no navegador através do endereço `http://localhost:4200/`.

---

## Modelo de Payload — Emissão de Receita Branca

Ao consumir o endpoint protegido de negócio (`POST /api/v1/numeracoes/receita-especial-retencao`), o formulário guia enviará a estrutura JSON contendo os dados do prescritor e do estabelecimento parceiro:

*   **Exemplo de Requisição Enviada pelo Front-end (JSON):**
    ```json
    {
      "conselho": "CRM",
      "tipo": "RET",
      "documento": "67666",
      "uf": "SP",
      "cnpj": "11111111000191"
    }
    ```

*   **Exemplo de Resposta de Sucesso do Servidor (JSON):**
    ```json
    {
      "inicio": "2605.7-35.0010001",
      "fim": "2605.7-35.0011000",
      "quantidade": 1000,
      "mensagem": "Numeração gerada com sucesso."
    }
    ```

    Diagrama de Sequência:
```text
    ┌─────────┐    ┌─────────────┐    ┌─────────────┐    ┌─────────┐    ┌─────────┐    ┌─────────┐
    │ Usuário │    │ AppComponent│    │ AuthService │    │ API SNCR│    │ Keycloak│    │ Gov.br  │
    └────┬────┘    └──────┬──────┘    └──────┬──────┘    └────┬────┘    └────┬────┘    └────┬────┘
         │                │                  │                │              │              │
         │                │                  │                │              │              │
         │ ════════════════ FLUXO DE LOGIN ══════════════════ │              │              │
         │                │                  │                │              │              │
         │ 1. Clique      │                  │                │              │              │
         │    "Entrar"    │                  │                │              │              │
         │───────────────>│                  │                │              │              │
         │                │                  │                │              │              │
         │                │ 2. getLoginUrl() │                │              │              │
         │                │─────────────────>│                │              │              │
         │                │                  │                │              │              │
         │                │ 3. Retorna URL   │                │              │              │
         │                │<─────────────────│                │              │              │
         │                │                  │                │              │              │
         │ 4. Redirect    │                  │                │              │              │
         │    window.location.href           │                │              │              │
         │<───────────────│                  │                │              │              │
         │                │                  │                │              │              │
         │ 5. Navegador segue URL            │                │              │              │
         │──────────────────────────────────────────────────> │              │              │
         │                │                  │                │              │              │
         │                │                  │                │ 6. GET /login│              │
         │                │                  │                │   (client_url)              │
         │                │                  │                │              │              │
         │                │                  │                │ 7. Redirect  │              │
         │                │                  │                │    Keycloak  │              │
         │                │                  │                │─────────────>│              │
         │                │                  │                │              │              │
         │                │                  │                │              │ 8. Redirect  │
         │                │                  │                │              │    Gov.br    │
         │                │                  │                │              │─────────────>│
         │                │                  │                │              │              │
         │ 9. Tela de Login Gov.br           │                │              │              │
         │<─────────────────────────────────────────────────────────────────────────────────│
         │                │                  │                │              │              │
         │ 10. Usuário faz login             │                │              │              │
         │──────────────────────────────────────────────────────────────────>│              │
         │                │                  │                │              │              │
         │                │                  │                │              │ 11. Callback │
         │                │                  │                │              │    (code)    │
         │                │                  │                │<─────────────│              │
         │                │                  │                │              │              │
         │                │                  │                │ 12. Troca    │              │
         │                │                  │                │     code por │              │
         │                │                  │                │     token    │              │
         │                │                  │                │─────────────>│              │
         │                │                  │                │              │              │
         │                │                  │                │ 13. Access   │              │
         │                │                  │                │     Token    │              │
         │                │                  │                │<─────────────│              │
         │                │                  │                │              │              │
         │                │                  │                │ 14. Gera     │              │
         │                │                  │                │     session_ │              │
         │                │                  │                │     token    │              │
         │                │                  │                │              │              │
         │ 15. Redirect com session_id       │                │              │              │
         │    ?session_id=xxx                │                │              │              │
         │<────────────────────────────────────────────────── │              │              │
         │                │                  │                │              │              │
         │ ════════════════ FLUXO DE CALLBACK ════════════════│              │              │
         │                │                  │                │              │              │
         │ 16. Acesso com session_id na URL  │                │              │              │
         │    (ngOnInit)                     │                │              │              │
         │───────────────>│                  │                │              │              │
         │                │                  │                │              │              │
         │                │ 17. processarCallback()           │              │              │
         │                │─────────────────>│                │              │              │
         │                │                  │                │              │              │
         │                │                  │ 18. GET /token │              │              │
         │                │                  │    ?session_id │              │              │
         │                │                  │───────────────>│              │              │
         │                │                  │                │              │              │
         │                │                  │ 19. Access     │              │              │
         │                │                  │     Token      │              │              │
         │                │                  │<───────────────│              │              │
         │                │                  │                │              │              │
         │                │ 20. Retorna token│                │              │              │
         │                │<─────────────────│                │              │              │
         │                │                  │                │              │              │
         │                │ 21. Salva token  │                │              │              │
         │                │     localStorage │                │              │              │
         │                │                  │                │              │              │
         │                │ 22. Limpa URL    │                │              │              │
         │                │     (remove      │                │              │              │
         │                │      session_id) │                │              │              │
         │                │                  │                │              │              │
         │ 23. Tela limpa, usuário autenticado                │              │              │
         │<───────────────│                  │                │              │              │
         │                │                  │                │              │              │
         │ ════════════════ REQUISIÇÃO PROTEGIDA ═════════════│              │              │
         │                │                  │                │              │              │
         │ 24.Faz consulta│                  │                │              │              │
         │───────────────>│                  │                │              │              │
         │                │                  │                │              │              │
         │                │ 25. getToken()   │                │              │              │
         │                │─────────────────>│                │              │              │
         │                │                  │                │              │              │
         │                │ 26. Retorna token│                │              │              │
         │                │<─────────────────│                │              │              │
         │                │                  │                │              │              │
         │                │ 27.POST /api/numeracoes/receita-especial-retencao│              │
         │                │     Authorization: Bearer token   │              │              │
         │                │──────────────────────────────────>│              │              │
         │                │                  │                │              │              │
         │                │                  │                │ 28. Processa │              │
         │                │                  │                │     valida   │              │
         │                │                  │                │     token    │              │
         │                │                  │                │              │              │
         │                │                  │                │ 29. Retorna  │              │
         │                │                  │                │     dados    │              │
         │                │                  │                │──────────────│              │
         │                │                  │                │              │              │
         │ 30. Exibe resultado               │                │              │              │
         │<───────────────│                  │                │              │              │
         │                │                  │                │              │              │
         │ ════════════════ FLUXO DE ERRO (401/400) ══════════│              │              │
         │                │                  │                │              │              │
         │ 31.Faz consulta│                  │                │              │              │
         │───────────────>│                  │                │              │              │
         │                │                  │                │              │              │
         │                │                  │                │ 32. Token    │              │
         │                │                  │                │     expirado │              │
         │                │                  │                │     ou erro  │              │
         │                │                  │                │     negócio  │              │
         │                │                  │                │              │              │
         │                │                  │ 33.Erro 401/400│              │              │
         │                │                  │<───────────────│              │              │
         │                │                  │                │              │              │
         │                │ 34. Trata erro   │                │              │              │
         │                │     (callback)   │                │              │              │
         │                │<─────────────────│                │              │              │
         │                │                  │                │              │              │
         │                │ 35. limparSessao()                │              │              │
         │                │─────────────────>│                │              │              │
         │                │                  │                │              │              │
         │ 36. Alert +    │                  │                │              │              │
         │    Redirect    │                  │                │              │              │
         │    para login  │                  │                │              │              │
         │<───────────────│                  │                │              │              │
         │                │                  │                │              │              │
```